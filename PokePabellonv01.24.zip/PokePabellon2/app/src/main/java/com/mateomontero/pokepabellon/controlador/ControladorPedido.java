package com.mateomontero.pokepabellon.controlador;

import com.mateomontero.pokepabellon.modelo.Pedido;

public class ControladorPedido {

    public boolean run(Pedido pedido) {

        return true;
    }
}
