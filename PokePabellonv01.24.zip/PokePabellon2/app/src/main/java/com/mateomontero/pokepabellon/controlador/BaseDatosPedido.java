package com.mateomontero.pokepabellon.controlador;

import android.content.ContentValues;
import android.content.Context;

import com.mateomontero.pokepabellon.modelo.Direccion;
import com.mateomontero.pokepabellon.modelo.Pedido;

public class BaseDatosPedido extends BaseDatos{
    public BaseDatosPedido(Context context) {
        super(context);
    }

    public void addPedido(Pedido pedido) {
        ContentValues cv = new ContentValues();



        db.insert("direccion", null, cv);


    }
}
