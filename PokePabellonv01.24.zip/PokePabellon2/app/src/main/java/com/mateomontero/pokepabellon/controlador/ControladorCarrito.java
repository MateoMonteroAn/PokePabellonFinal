package com.mateomontero.pokepabellon.controlador;

import com.mateomontero.pokepabellon.modelo.Carrito;
import com.mateomontero.pokepabellon.modelo.Producto;

import java.util.ArrayList;

public class ControladorCarrito {
    public ArrayList<Carrito> run() {
        return null;

    }
}
