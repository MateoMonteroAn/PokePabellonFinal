package com.mateomontero.pokepabellon.controlador;

import android.content.Context;

public class BaseDatosPedidoProducto extends BaseDatos{
    public BaseDatosPedidoProducto(Context context) {
        super(context);
    }

}
