package com.mateomontero.pokepabellon.controlador;

import android.content.Context;

public class ControladorBase extends BaseDatos {
    public ControladorBase(Context context) {
        super(context);
    }


}
