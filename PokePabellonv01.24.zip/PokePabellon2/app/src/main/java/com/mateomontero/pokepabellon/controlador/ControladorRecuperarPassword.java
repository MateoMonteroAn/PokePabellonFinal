package com.mateomontero.pokepabellon.controlador;

public class ControladorRecuperarPassword {

    public String run(String correo){

        return  "";
    }
}
