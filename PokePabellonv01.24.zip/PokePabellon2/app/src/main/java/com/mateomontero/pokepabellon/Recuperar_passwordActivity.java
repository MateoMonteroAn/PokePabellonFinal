package com.mateomontero.pokepabellon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.mateomontero.pokepabellon.controlador.ControladorRecuperarPassword;
import com.mateomontero.pokepabellon.modelo.Carrito;
import com.mateomontero.pokepabellon.modelo.Datos;
import com.mateomontero.pokepabellon.modelo.Pedido;
import com.mateomontero.pokepabellon.modelo.Usuario;

public class Recuperar_passwordActivity extends AppCompatActivity {
  Datos datos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_password);


        try {
            Bundle b = getIntent().getExtras();
            datos=(Datos)b.getSerializable("capsula");
        }
        catch (Exception e){}
        datos=new Datos();

        Button b_main = (Button) findViewById(R.id.RecuperarActivity_botonMain);
        Button b_recuperar = (Button) findViewById(R.id.RecuperarActivity_BotonRecuperar);
        b_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Recuperar_passwordActivity.this, MainActivity.class);
            i.putExtra("capsula",datos);
                startActivity(i);
                finish();
            }
        });
        b_recuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password="";
                String a=new ControladorRecuperarPassword().run(password);
                Intent i = new Intent(Recuperar_passwordActivity.this, UserActivity.class);
                startActivity(i);
                 i.putExtra("capsula",datos);
                finish();
            }
        });
    }
}