package com.mateomontero.pokepabellon;

public class DatosProducto {

    String nombre;
    double precio;

}
