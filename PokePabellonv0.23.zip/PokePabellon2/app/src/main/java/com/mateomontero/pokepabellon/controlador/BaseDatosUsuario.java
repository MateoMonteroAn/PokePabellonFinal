package com.mateomontero.pokepabellon.controlador;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import com.mateomontero.pokepabellon.modelo.Usuario;

public class BaseDatosUsuario  extends BaseDatos{


    public BaseDatosUsuario(Context context) {
        super(context);
    }
    //añadir usuario
    public void actualizarUsuario(Usuario usuario){
        ContentValues cv=new ContentValues();
        cv.put("nombre",usuario.getNombre());
        cv.put("correo",usuario.getCorreo());
        cv.put("password",usuario.getPassward());
        cv.put("tipo",usuario.isAdmin());
        db.update("Usuarios", cv,  " _id = " + usuario.getId(), null);

    }

    //añadir usuario dando el id
    public void deleteUsuario(int id) {
        // Elimina la nota seleccionada
        db.delete("usuarios", " _id = " + id, null);
    }



    public void deleteAllUsuarios() {
        // Elimina la nota seleccionada
        db.delete("usuarios",null, null);
    }


    public void addUsuario(Usuario usuario) {
        ContentValues cv=new ContentValues();
        cv.put("nombre",usuario.getNombre());
        cv.put("correo",usuario.getCorreo());
        cv.put("password",usuario.getPassward());
        cv.put("tipo",usuario.isAdmin());
        db.insert("Usuarios", null,cv);


    }

    public Usuario login( String correo, String password) {

        String sentenciaSql = "SELECT *" +
                "" + " FROM usuarios"   ;

        Cursor c=null;
        try {
            c = db.rawQuery(sentenciaSql, null);
        }
        catch (Exception e){
            return null;
        }
        if (c != null && c.getCount() > 0) {
            c.moveToFirst();
            do {
                int id = c.getInt(c.getColumnIndexOrThrow("_id"));
                String nombre = c.getString(c.getColumnIndexOrThrow("nombre"));
                String correo2 = c.getString(c.getColumnIndexOrThrow("correo"));
                String password2 = c.getString(c.getColumnIndexOrThrow("password"));

                if (correo2.equals(correo) && password2.equals(password)){
                    Usuario u=new Usuario(nombre,correo,password);
                    u.setId(id);
                    return u;
                }
            } while (c.moveToNext());
        }
        c.close();
        return null;
    }
    public boolean Registrar(Usuario usuario) {
// Gets the data repository in write mode
        ContentValues cv=new ContentValues();
        cv.put("nombre",usuario.getNombre().toString());
        cv.put("correo",usuario.getCorreo().toString());
        cv.put("password",usuario.getPassward().toString());
        cv.put("tipo",usuario.isAdmin());
        db.insert("Usuarios",null, cv);

        return usuario.isAdmin();
    }



}
