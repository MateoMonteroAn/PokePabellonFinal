package com.mateomontero.pokepabellon.controlador;

import com.mateomontero.pokepabellon.modelo.Usuario;

public class ControladorRegistro {

    public boolean run(String nombre, String correo, String password) {

        return true;
    }

}
