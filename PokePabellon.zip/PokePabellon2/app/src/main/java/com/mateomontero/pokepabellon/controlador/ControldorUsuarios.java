package com.mateomontero.pokepabellon.controlador;

import com.mateomontero.pokepabellon.modelo.Carrito;
import com.mateomontero.pokepabellon.modelo.Usuario;

import java.util.ArrayList;

public class ControldorUsuarios {
    public ArrayList<Usuario> run() {
        return new BBDD().getUsuarios();

    }
}
