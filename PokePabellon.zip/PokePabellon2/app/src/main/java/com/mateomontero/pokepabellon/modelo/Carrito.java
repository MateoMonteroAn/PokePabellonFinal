package com.mateomontero.pokepabellon.modelo;

import java.io.Serializable;

public class Carrito implements Serializable {
    private Producto producto;
}
